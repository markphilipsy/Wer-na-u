<html>
<head></head>
<body>
<form action="chikka.php" method="post">
<textarea name="smsMsg">#WebGeekDevCup</textarea>
<br>
<input type="submit" value="Send SMS">
</form>
</body>

</html>
